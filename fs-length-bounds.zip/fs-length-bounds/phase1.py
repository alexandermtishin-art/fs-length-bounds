import numpy as np
from scipy.integrate import solve_ivp
def test(O,dO,T,n=200001,label=''):
    # integrate u,v,theta and F
    def rhs(t,y):
        u=y[0]+1j*y[1]; v=y[2]+1j*y[3]; th=y[4]
        c=dO(t)/(2*O(t))
        du=c*np.exp(2j*th)*v; dv=c*np.exp(-2j*th)*u; dF=c*np.exp(-2j*th)
        return [du.real,du.imag,dv.real,dv.imag,O(t),dF.real,dF.imag,abs(c)]
    s=solve_ivp(rhs,(0,T),[1,0,0,0,0,0,0,0],rtol=1e-11,atol=1e-13,t_eval=np.linspace(0,T,n),method='DOP853')
    v=s.y[2]+1j*s.y[3]; N=abs(v)**2; F=abs(s.y[5]+1j*s.y[6]); Phi=np.maximum.accumulate(F); Th=s.y[7]
    BV=np.sinh(Th)**2
    with np.errstate(over='ignore',invalid='ignore'):
        PB=np.where(Phi<1,(Phi/(1-Phi)*np.exp(Phi*Th/(1-Phi)))**2,np.inf)
    k=-1
    print(f"{label:28s} N_end={N[k]:.3e} maxN={N.max():.3e} BV={BV[k]:.3e} Phi={Phi[k]:.3e} phase-bound={PB[k]:.3e} viol={np.max(N-np.minimum(BV,PB)):.1e}")
eps=0.02
test(lambda t:1+eps*np.sin(2*t),lambda t:2*eps*np.cos(2*t),100*np.pi,label='resonant')
test(lambda t:1+eps*np.sin(1.3*t),lambda t:1.3*eps*np.cos(1.3*t),100*np.pi,label='off-res 1.3')
test(lambda t:1+eps*np.sin(1.3*t),lambda t:1.3*eps*np.cos(1.3*t),20*np.pi,label='res check short')
for tau in [0.05,0.3,1,2]:
    t0=6*tau+2
    test(lambda t:0.75-0.25*np.tanh((t-t0)/tau),lambda t:-0.25/tau/np.cosh((t-t0)/tau)**2,2*t0+5,label=f'tanh 1->0.5 tau={tau}')
for tau in [0.3,1,2]:
    t0=6*tau+2
    test(lambda t:1.5+0.5*np.tanh((t-t0)/tau),lambda t:0.5/tau/np.cosh((t-t0)/tau)**2,2*t0+5,label=f'tanh 1->2 tau={tau}')
