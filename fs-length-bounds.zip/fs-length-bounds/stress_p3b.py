import numpy as np
src=open('phase_mm.py').read().split("def R(th)")[0]; exec(src)
rng=np.random.default_rng(5); res=[]
for trial in range(40):
    M=int(rng.integers(2,4))
    Q=rng.normal(size=(M,M)); V0=Q@Q.T+np.eye(M)
    P=rng.normal(size=(M,M)); P=(P+P.T)/2; P/=np.linalg.norm(P,2)
    kind=int(rng.integers(0,2)); w=rng.uniform(0.2,4); amp=rng.uniform(0.05,0.6)*np.linalg.eigvalsh(V0).min(); tau=10**rng.uniform(-1.5,0.5)
    if kind==0: Vf=lambda t,V0=V0,P=P,w=w,amp=amp: V0+amp*np.sin(w*t)*P
    else: Vf=lambda t,V0=V0,P=P,tau=tau,amp=amp: V0+amp*np.tanh((t-4)/tau)*P
    if min(np.linalg.eigvalsh(Vf(t)).min() for t in np.linspace(0,12,100))<0.05: continue
    N,PB,PF,Th=run(Vf,12,M,steps=2401)
    v=np.max(N-PB); res.append((v,PF[-1],N.max(),PB[-1]))
    print(f"M={M} kind={kind} maxN={N.max():.3e} PhiF={PF[-1]:.3f} bound={PB[-1]:.3e} viol={v:.1e}")
print('max violation',max(r[0] for r in res), 'n',len(res), 'with PhiF<1:',sum(r[1]<1 for r in res))
r=np.array([(x[3]/x[2],x[1]) for x in res if x[1]<1])
print('ratios bound/maxN (PhiF<1):',np.round(np.sort(r[:,0]),2))
print('quantiles',np.percentile(r[:,0],[0,25,50,75,90,100]))
for lo,hi in [(0,0.1),(0.1,0.3),(0.3,0.6),(0.6,1)]:
    s=r[(r[:,1]>=lo)&(r[:,1]<hi),0]; print(lo,hi,len(s),(s.min(),np.median(s),s.max()) if len(s) else '')
