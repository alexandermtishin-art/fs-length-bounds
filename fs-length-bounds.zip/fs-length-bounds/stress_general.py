# Random test of N <= sinh^2(sqrt2 d_G) <= sinh^2(sqrt2 L_FS) for general H = xi^T h(t) xi /2 with x-p terms
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import sqrtm, inv, eigh
rng=np.random.default_rng(7)
def Jm(M): return np.block([[np.zeros((M,M)),np.eye(M)],[-np.eye(M),np.zeros((M,M))]])
def ground_cov(h,J):
    s=np.real(sqrtm(h)); X=s@J@s; A=np.real(sqrtm(-X@X)); si=inv(s)
    return 0.5*si@A@si
def symp_of_cov(sig):
    # find S with sig = S S^T /2 (Williamson for pure state): S = sqrt(2 sig) is symplectic? use S = (2sig)^{1/2} (symmetric positive symplectic for pure states)
    return np.real(sqrtm(2*sig))
def run(M,T,hfun,n=2001):
    J=Jm(M); h0=hfun(0); sig0=ground_cov(h0,J)
    def rhs(t,y):
        s=y.reshape(2*M,2*M); A=J@hfun(t); return (A@s+s@A.T).ravel()
    ts=np.linspace(0,T,n)
    sol=solve_ivp(rhs,(0,T),sig0.ravel(),t_eval=ts,rtol=1e-10,atol=1e-12,method='DOP853')
    N=[];L=[0.0];dG=[];prev=None
    for k,t in enumerate(ts):
        sig=sol.y[:,k].reshape(2*M,2*M); g=ground_cov(hfun(t),J)
        S=symp_of_cov(g); Si=inv(S)
        rel=2*Si@sig@Si.T          # covariance relative to vacuum normalized: vacuum -> I
        N.append(0.25*np.trace(rel)-M/2)
        ev=np.sort(np.linalg.eigvalsh(rel))   # eigenvalues e^{±2r}
        r=0.5*np.log(ev[-M:]); dG.append(np.sqrt(np.sum(r**2))/np.sqrt(2))
        if prev is not None:
            dg=g-prev; gi=inv((g+prev)/2); L.append(L[-1]+np.sqrt(max(np.trace(gi@dg@gi@dg),0)/16))
        prev=g
    N=np.array(N);L=np.array(L);dG=np.array(dG)
    return N,dG,L
worst=[]
for trial in range(40):
    M=rng.integers(1,4)
    # random positive h0 with x-p blocks, random smooth time dependence
    Q=rng.normal(size=(2*M,2*M)); h0=Q@Q.T+2*np.eye(2*M)
    P=[rng.normal(size=(2*M,2*M)) for _ in range(2)]; P=[(p+p.T)/2 for p in P]
    w=rng.uniform(0.3,3,2); amp=rng.uniform(0.1,1.0)
    kind=rng.integers(0,2)
    def hfun(t,h0=h0,P=P,w=w,amp=amp,kind=kind):
        if kind==0: return h0+amp*(np.sin(w[0]*t)*P[0]+np.sin(w[1]*t)*P[1])   # periodic
        return h0+amp*np.tanh((t-3)/(0.1+w[0]/3))*P[0]+amp*np.tanh((t-4)/(0.1+w[1]/3))*P[1]
    # ensure positivity along path
    ok=all(np.linalg.eigvalsh(hfun(t)).min()>0.2 for t in np.linspace(0,10,200))
    if not ok: continue
    N,dG,L=run(M,10,hfun)
    v1=np.max(N-np.sinh(np.sqrt(2)*dG)**2); v2=np.max(dG-L); 
    worst.append((v1,v2)); 
    print(f"M={M} kind={kind} Nmax={N.max():.3e} viol(N-sinh2 dG)={v1:.1e} viol(dG-L)={v2:.1e} ratio N/sinh2L={N[-1]/max(np.sinh(np.sqrt(2)*L[-1])**2,1e-30):.3f}")
print('max violations',max(x[0] for x in worst),max(x[1] for x in worst), len(worst))
