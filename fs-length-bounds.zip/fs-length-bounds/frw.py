import numpy as np
from scipy.integrate import solve_ivp, quad
A,Bc,m=2.0,1.0,1.0
def exact(k,rho):
    wi=np.sqrt(k*k+m*m*(A-Bc)); wo=np.sqrt(k*k+m*m*(A+Bc)); wm=(wo-wi)/2
    return np.sinh(np.pi*wm/rho)**2/(np.sinh(np.pi*wi/rho)*np.sinh(np.pi*wo/rho))
def bound(k):
    wi=np.sqrt(k*k+m*m*(A-Bc)); wo=np.sqrt(k*k+m*m*(A+Bc)); return (wo-wi)**2/(4*wi*wo)
def numeric(k,rho,T=None):
    T=T or 40/rho+20
    om=lambda t:np.sqrt(k*k+m*m*(A+Bc*np.tanh(rho*t)))
    t0=-T; w0=om(t0); f0=1/np.sqrt(2*w0)
    s=solve_ivp(lambda t,y:[y[1],-om(t)**2*y[0]],(t0,T),[f0+0j,-1j*w0*f0],rtol=1e-11,atol=1e-13)
    f,fd=s.y[0,-1],s.y[1,-1]; w=om(T); return abs(w*f-1j*fd)**2/(2*w)
for rho in [0.5,2,10]:
    for k in [0.0,1.0,3.0]:
        print(rho,k, f"exact={exact(k,rho):.4e} numeric={numeric(k,rho):.4e} bound={bound(k):.4e}")
for rho in [0.5,2,10,100]:
    n=quad(lambda k:k*k*exact(k,rho),0,np.inf,limit=400)[0]/(2*np.pi**2)
    nb=quad(lambda k:k*k*bound(k),0,np.inf,limit=400)[0]/(2*np.pi**2)
    print('density rho',rho,f"n={n:.4e} bound={nb:.4e} ratio={n/nb:.3f}")
