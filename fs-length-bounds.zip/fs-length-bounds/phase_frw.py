import numpy as np
from scipy.integrate import solve_ivp, quad
A,B,m=2.0,1.0,1.0
def exact(k,rho):
    wi=np.sqrt(k*k+m*m*(A-B)); wo=np.sqrt(k*k+m*m*(A+B)); wm=(wo-wi)/2
    x=np.pi/rho
    return np.exp(2*np.log(np.sinh(x*wm))-np.log(np.sinh(x*wi))-np.log(np.sinh(x*wo))) if x*wo<300 else np.exp(2*x*wm-x*wi-x*wo)*4/4
def sudden(k):
    wi=np.sqrt(k*k+m*m*(A-B)); wo=np.sqrt(k*k+m*m*(A+B)); return (wo-wi)**2/(4*wi*wo)
def phase(k,rho):
    T=30/rho+5
    om=lambda t:np.sqrt(k*k+m*m*(A+B*np.tanh(rho*t)))
    c=lambda t:m*m*B*rho/np.cosh(rho*t)**2/(4*om(t)**2)
    def rhs(t,y):
        u=y[0]+1j*y[1]; v=y[2]+1j*y[3]; th=y[4]; cc=c(t)
        du=cc*np.exp(2j*th)*v; dv=cc*np.exp(-2j*th)*u; dF=cc*np.exp(-2j*th)
        return [du.real,du.imag,dv.real,dv.imag,om(t),dF.real,dF.imag,abs(cc)]
    s=solve_ivp(rhs,(-T,T),[1,0,0,0,0,0,0,0],rtol=1e-10,atol=1e-13,method='DOP853',dense_output=True)
    ts=np.linspace(-T,T,20001); y=s.sol(ts)
    F=np.abs(y[5]+1j*y[6]); Phi=F.max(); Th=y[7,-1]; N=np.abs(y[2]+1j*y[3])**2
    PB=(Phi/(1-Phi)*np.exp(Phi*Th/(1-Phi)))**2 if Phi<1 else np.inf
    return N.max(), N[-1], min(PB,sudden(k)), PB
for rho in []:
    for k in [0,1,3]:
        mx,end,b,pb=phase(k,rho)
        print(rho,k,f"exact={exact(k,rho):.3e} Nend={end:.3e} maxN={mx:.3e} phasebound={pb:.3e} sudden={sudden(k):.3e}")
ks=np.concatenate([np.linspace(0,5,26),np.linspace(5.5,40,30)])
for rho in [0.5,2,10,100]:
    vals=[min(phase(k,rho)[3],sudden(k)) for k in ks]
    nb=np.trapezoid(ks**2*np.array(vals),ks)/(2*np.pi**2); ns=np.trapezoid(ks**2*np.array([sudden(k) for k in ks]),ks)/(2*np.pi**2)
    print('rho',rho,'n_bound_phase(k<40)',f"{nb:.3e}",'n_sudden(k<40)',f"{ns:.3e}")
