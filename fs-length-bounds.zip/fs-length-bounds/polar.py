import numpy as np
from scipy.linalg import sqrtm, expm
from scipy.integrate import solve_ivp
import sys; NT=int(sys.argv[1]); rng=np.random.default_rng(3)
def Jm(M): return np.block([[np.zeros((M,M)),np.eye(M)],[-np.eye(M),np.zeros((M,M))]])
def polarS(h,J):
    hs=np.real(sqrtm(h)); hi=np.linalg.inv(hs); X=hs@J@hs
    absX=np.real(sqrtm(X.T@X)); g=0.5*hi@absX@hi; return np.real(sqrtm(2*g))
def ab(Msym,M):
    A=Msym[:M,:M];Bq=Msym[:M,M:];C=Msym[M:,:M];D=Msym[M:,M:]
    al=0.5*((A+D)+1j*(C-Bq)); be=0.5*((A-D)+1j*(C+Bq)); return al,be
for trial in range(12):
    M=int(rng.integers(2,4)); J=Jm(M)
    Q=rng.normal(size=(2*M,2*M)); h0=Q@Q.T+1.5*np.eye(2*M)
    P=rng.normal(size=(2*M,2*M)); P=(P+P.T)/2; P/=np.linalg.norm(P,2)
    amp=rng.uniform(0.3,0.9)*np.linalg.eigvalsh(h0).min(); kind=trial%2; w=rng.uniform(0.5,3); tau=10**rng.uniform(-1.5,0)
    hf=(lambda t: h0+amp*np.sin(w*t)*P) if kind==0 else (lambda t: h0+amp*np.tanh((t-2)/tau)*P)
    T=6.0; ts=np.linspace(0,T,NT)
    sol=solve_ivp(lambda t,y:(J@hf(t)@y.reshape(2*M,2*M)).ravel(),(0,T),np.eye(2*M).ravel(),t_eval=ts,rtol=1e-10,atol=1e-12)
    S0=polarS(hf(0),J); Ss=[polarS(hf(t),J) for t in ts]
    N=[];BF=[];BO=[]
    for k,t in enumerate(ts):
        Phi=sol.y[:,k].reshape(2*M,2*M); Mx=np.linalg.inv(Ss[k])@Phi@S0
        al,be=ab(Mx,M); N.append(np.linalg.norm(be)**2)
        kk=min(max(k,1),len(ts)-2); Sd=(Ss[kk+1]-Ss[kk-1])/(ts[kk+1]-ts[kk-1])
        L=np.linalg.inv(Ss[k])@Sd; La=(L+J@L@J)/2
        BF.append(np.linalg.norm(La)/np.sqrt(2)); BO.append(np.linalg.norm(La,2))
    N=np.array(N);BF=np.array(BF);BO=np.array(BO)
    cum=lambda f: np.concatenate([[0],np.cumsum((f[1:]+f[:-1])/2*np.diff(ts))])
    Th=cum(BO); sL=cum(BF); b18=cum(BF*np.cosh(Th))**2; b16=np.sinh(sL)**2
    print(f"M={M} kind={kind} maxN={N.max():.3e} max N/b18={np.max(np.where(b18>1e-10,N/np.maximum(b18,1e-300),0)):.5f} max N/b16={np.max(np.where(b16>1e-10,N/np.maximum(b16,1e-300),0)):.5f} b18/b16(T)={b18[-1]/b16[-1]:.3f} sympl={np.abs(np.linalg.norm(al)**2-np.linalg.norm(be)**2-M):.1e}")
