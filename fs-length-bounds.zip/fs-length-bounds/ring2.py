import numpy as np, sys, time
sys.path.insert(0,'.')
from ring import setup
from scipy.integrate import solve_ivp
from scipy.linalg import sqrtm
def frame(V,Vd,t):
    a2,U=np.linalg.eigh(V(t)); a=np.sqrt(a2); Vt=U.T@Vd(t)@U
    Ad=Vt/(a[:,None]+a[None,:]); sa=np.sqrt(a)
    Pd=Ad/(sa[:,None]+sa[None,:])
    A=U@np.diag(a)@U.T; P=U@np.diag(sa)@U.T; Pi=U@np.diag(1/sa)@U.T
    B=U@(Ad/(2*np.outer(sa,sa)))@U.T; PdL=U@Pd@U.T
    K=0.5*(PdL@Pi-Pi@PdL)
    return A,B,K
def run(M,D=4.0,v=1.0,dt=0.004):
    V,Vd,T=setup(M,D=D,vmax=v)
    n=int(np.ceil(T/dt)); dt=T/n
    W=np.eye(M,dtype=complex); Z=np.zeros((M,M),complex)
    alpha=np.eye(M,dtype=complex); beta=np.zeros((M,M),complex)
    PhF=PhO=0; Th=0; sL=0; I18=0; Nmax=0
    def f(t,Y):
        W,Z,al,be=Y; A,B,K=frame(V,Vd,t)
        Wd=(-1j*A+K)@W
        return [Wd, W.conj().T@B@W.conj(), (-1j*A+K)@al+B@be.conj(), (-1j*A+K)@be+B@al.conj()], B
    Y=[W,Z,alpha,beta]
    for k in range(n):
        t=k*dt
        k1,B1=f(t,Y); k2,_=f(t+dt/2,[y+dt/2*q for y,q in zip(Y,k1)])
        k3,_=f(t+dt/2,[y+dt/2*q for y,q in zip(Y,k2)]); k4,B4=f(t+dt,[y+dt*q for y,q in zip(Y,k3)])
        Y=[y+dt/6*(a+2*b+2*c+d) for y,a,b,c,d in zip(Y,k1,k2,k3,k4)]
        for Bx,wgt in ((B1,0.5),(B4,0.5)):
            s=np.linalg.svd(Bx,compute_uv=False); bf=np.sqrt((s**2).sum())
            I18+=wgt*dt*bf*np.cosh(Th); sL+=wgt*dt*bf; Th+=wgt*dt*s[0]
        sz=np.linalg.svd(Y[1],compute_uv=False); PhF=max(PhF,np.sqrt((sz**2).sum())); PhO=max(PhO,sz[0])
        Nmax=max(Nmax,np.linalg.norm(Y[3])**2)
    N=np.linalg.norm(Y[3])**2
    p3=(PhF/(1-PhF)*np.exp(PhO*Th/(1-PhF)))**2 if PhF<1 else np.inf
    return dict(M=M,v=v,N=N,Nmax=Nmax,eq16=np.sinh(sL)**2,eq18=I18**2,new=sL**2*np.sinh(Th)**2/Th**2,PhiF=PhF,PhiO=PhO,Theta=Th,prop3=p3)
if __name__=='__main__':
    M=int(sys.argv[1])
    for v in map(float,sys.argv[2].split(',')):
        t0=time.time(); r=run(M,v=v); r['sec']=round(time.time()-t0)
        print({k:(float('%.4g'%x) if isinstance(x,(float,np.floating)) else x) for k,x in r.items()},flush=True)
