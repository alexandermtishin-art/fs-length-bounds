import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import eigh
def mats(Vf,t):
    w,U=eigh(Vf(t)); P=U@np.diag(w**0.25)@U.T; A=U@np.diag(w**0.5)@U.T; return A,P
def run(Vf,T,M,steps=3001,h=1e-5):
    def deriv(t):
        A,P=mats(Vf,t); Ap,Pp=mats(Vf,t+h); Am,Pm=mats(Vf,t-h)
        Pd=(Pp-Pm)/(2*h); Ad=(Ap-Am)/(2*h); Pi=np.linalg.inv(P)
        K=0.5*(Pd@Pi-Pi@Pd); B=0.5*Pi@Ad@Pi
        return A,K,B
    def rhs(t,y):
        W=y[:M*M].reshape(M,M); al=y[M*M:2*M*M].reshape(M,M); be=y[2*M*M:3*M*M].reshape(M,M)
        A,K,B=deriv(t); G=-1j*A+K
        C=W.conj().T@B@W.conj()
        return np.concatenate([(G@W).ravel(),(G@al+B@be.conj()).ravel(),(G@be+B@al.conj()).ravel(),C.ravel(),
                               [np.linalg.norm(B,2)]])
    y0=np.concatenate([np.eye(M).ravel(),np.eye(M).ravel(),np.zeros(M*M),np.zeros(M*M),[0]]).astype(complex)
    ts=np.linspace(0,T,steps)
    s=solve_ivp(rhs,(0,T),y0,t_eval=ts,rtol=1e-9,atol=1e-11,method='DOP853')
    N=[];PF=[];PO=[];Th=[]
    for k in range(len(ts)):
        be=s.y[2*M*M:3*M*M,k].reshape(M,M); F=s.y[3*M*M:4*M*M,k].reshape(M,M)
        N.append(np.linalg.norm(be)**2); PF.append(np.linalg.norm(F)); PO.append(np.linalg.norm(F,2)); Th.append(s.y[-1,k].real)
    N=np.array(N);PF=np.maximum.accumulate(PF);PO=np.maximum.accumulate(PO);Th=np.array(Th)
    with np.errstate(over='ignore',invalid='ignore'):
        PB=np.where(PF<1,(PF/(1-PF)*np.exp(PO*Th/(1-PF)))**2,np.inf)
    return N,PB,PF,Th
def R(th): return np.array([[np.cos(th),-np.sin(th)],[np.sin(th),np.cos(th)]])
cases={}
for kap in [0.5,2]:
    cases[f'rot k={kap}']=(lambda t,k=kap:R(k*np.tanh(t-3))@np.diag([1,9])@R(k*np.tanh(t-3)).T,8,2)
cases['resonant']=(lambda t:np.array([[1+0.05*np.sin(2*t),0.3],[0.3,2.25]]),60,2)
cases['quench']=(lambda t:np.array([[1,0.45*(1+np.tanh((t-3)/0.05))],[0.45*(1+np.tanh((t-3)/0.05)),2.25]]),8,2)
cases['sumfreq']=(lambda t:np.array([[1,0.08*np.cos(2.5*t)],[0.08*np.cos(2.5*t),2.25]]),80,2)
cases['difffreq off']=(lambda t:np.array([[1,0.08*np.cos(0.9*t)],[0.08*np.cos(0.9*t),2.25]]),80,2)
for k,(Vf,T,M) in cases.items():
    N,PB,PF,Th=run(Vf,T,M)
    print(f"{k:14s} N_end={N[-1]:.3e} maxN={N.max():.3e} PhiF={PF[-1]:.3e} Theta={Th[-1]:.3f} phasebound={PB[-1]:.3e} viol={np.max(N-PB):.1e}")
