import numpy as np
exec(open('stress_general.py').read().split("worst=[]")[0])
rng=np.random.default_rng(11); worst=[]; ratios=[]
for trial in range(60):
    M=int(rng.integers(1,4))
    Q=rng.normal(size=(2*M,2*M)); h0=Q@Q.T+1.5*np.eye(2*M)
    P=rng.normal(size=(2*M,2*M)); P=(P+P.T)/2; P=P/np.linalg.norm(P,2)
    amp=rng.uniform(0.5,1.2)*np.linalg.eigvalsh(h0).min(); tau=10**rng.uniform(-2.3,0)
    hfun=lambda t,h0=h0,P=P,amp=amp,tau=tau: h0+amp*np.tanh((t-2)/tau)*P
    if min(np.linalg.eigvalsh(hfun(t)).min() for t in np.linspace(0,4,100))<0.05: continue
    N,dG,L=run(M,4,hfun,n=4001)
    v1=np.max(N-np.sinh(np.sqrt(2)*dG)**2); v2=np.max(dG-L)
    worst.append((v1,v2)); ratios.append(N[-1]/np.sinh(np.sqrt(2)*L[-1])**2)
print(len(worst),'max viol',max(w[0] for w in worst),max(w[1] for w in worst),'max ratio N/bound',max(ratios),'median',np.median(ratios))
