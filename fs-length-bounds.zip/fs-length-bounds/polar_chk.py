import numpy as np
from scipy.linalg import sqrtm
import sys; sys.argv=['x','10']
exec(open('polar.py').read().split('for trial')[0])
rng=np.random.default_rng(9)
for tr in range(4):
    M=int(rng.integers(2,4)); J=Jm(M)
    Q=rng.normal(size=(2*M,2*M)); h0=Q@Q.T+1.5*np.eye(2*M); P=rng.normal(size=(2*M,2*M)); P=(P+P.T)/2
    hf=lambda t: h0+0.3*np.sin(t)*P
    t=0.7; h=hf(t); S=polarS(h,J)
    R=S.T@h@S; print('comm [S^T h S, J]',np.linalg.norm(R@J-J@R), ' S symplectic',np.linalg.norm(S.T@J@S-J))
    dt=1e-5; Sp=polarS(hf(t+dt),J); Sm=polarS(hf(t-dt),J); Sd=(Sp-Sm)/(2*dt)
    L=np.linalg.inv(S)@Sd; La=(L+J@L@J)/2; BF=np.linalg.norm(La)/np.sqrt(2)
    sig=lambda t: polarS(hf(t),J)@polarS(hf(t),J).T/2
    s=sig(t); sd=(sig(t+dt)-sig(t-dt))/(2*dt); X=np.linalg.inv(s)@sd
    vfs=np.sqrt(np.trace(X@X)/16)
    print('  ||B||_F',BF,' sqrt2 vFS',np.sqrt(2)*vfs)
