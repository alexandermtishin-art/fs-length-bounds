import numpy as np, sys, json
sys.path.insert(0,'.')
from ring import setup
from ring2 import frame
def Xof(V,Vd,t):
    A,B,K=frame(V,Vd,t); a2,U=np.linalg.eigh(V(t)); a=np.sqrt(a2)
    Be=U.T@B@U; Xe=-1j*Be/(a[:,None]+a[None,:]); return U@Xe@U.T, K
def apriori(M=20,D=4.0,v=1.0,dt=0.002,h=1e-5):
    V,Vd,T=setup(M,D=D,vmax=v); ts=np.arange(0,T+dt/2,dt)
    X0,_=Xof(V,Vd,0.0); nF0=np.linalg.norm(X0); nO0=np.linalg.norm(X0,2)
    IF=IO=0; PF=PO=0; Th=0; prev=None
    for t in ts:
        X,K=Xof(V,Vd,t); Xp,_=Xof(V,Vd,t+h); Xm,_=Xof(V,Vd,max(t-h,0)); Xd=(Xp-Xm)/(2*h if t>=h else h)
        R=Xd-(K@X-X@K); rF=np.linalg.norm(R); rO=np.linalg.norm(R,2)
        if prev is not None: IF+=dt*(rF+prev[0])/2; IO+=dt*(rO+prev[1])/2
        prev=(rF,rO)
        PF=max(PF,nF0+np.linalg.norm(X)+IF); PO=max(PO,nO0+np.linalg.norm(X,2)+IO)
        _,B,_=frame(V,Vd,t); 
        if t>0: Th+=dt*np.linalg.norm(B,2)
    bnd=(PF/(1-PF)*np.exp(PO*Th/(1-PF)))**2 if PF<1 else np.inf
    return dict(v=v,PhiF_apriori=PF,PhiO_apriori=PO,Theta=Th,bound=bnd)
if __name__=='__main__':
    sc={x['v']:x for x in json.load(open('ringscan.json'))}
    out=[]
    for v in sorted(sc)[::2]:
        r=apriori(v=v); r.update(Nmax=sc[v]['Nmax'],PhiF_exact=sc[v]['PhiF'],prop3=sc[v]['prop3']); out.append(r)
        print({k:float('%.4g'%x) for k,x in r.items()},flush=True)
    json.dump(out,open('kato_mm.json','w'))
