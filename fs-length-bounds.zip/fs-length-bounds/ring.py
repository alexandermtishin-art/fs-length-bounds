import numpy as np, sys, time
from scipy.integrate import solve_ivp
from scipy.linalg import sqrtm
# ring of M oscillators, Gaussian defect of strength g0 moved by distance D with smooth velocity profile
def setup(M,J=0.5,g0=1.0,w=1.5,D=None,vmax=1.0):
    D=M/2 if D is None else D
    S=np.roll(np.eye(M),1,axis=1); V0=(1+2*J)*np.eye(M)-J*(S+S.T)
    Tm=1.5*D/vmax       # profile x0 = D*s(u), s = smoothstep (3u^2-2u^3), max speed 1.5 D/Tm
    T=Tm+4.0; t1=2.0; j=np.arange(M)
    def u(t): return np.clip((t-t1)/Tm,0,1)
    def x0(t): uu=u(t); return M/4+D*(3*uu**2-2*uu**3)
    def x0d(t): uu=u(t); return D*6*uu*(1-uu)/Tm
    def prof(t):
        d=(j-x0(t)+M/2)%M-M/2; return np.exp(-d**2/w**2),d
    def V(t): p,_=prof(t); return V0+np.diag(g0*p)
    def Vd(t): p,d=prof(t); return np.diag(g0*p*2*d/w**2*x0d(t))
    return V,Vd,T
def run(M,**kw):
    V,Vd,T=setup(M,**kw)
    ts=np.linspace(0,T,int(T*100)+1); Bf=[];Bo=[];per=[]
    for t in ts:
        a2,U=np.linalg.eigh(V(t)); a=np.sqrt(a2)
        B=(U.T@Vd(t)@U)/(2*(a[:,None]+a[None,:])*np.sqrt(np.outer(a,a)))
        s=np.linalg.svd(B,compute_uv=False); Bf.append(np.sqrt((s**2).sum())); Bo.append(s[0])
        per.append(a)
    Bf=np.array(Bf);Bo=np.array(Bo);per=np.array(per)
    cum=lambda f: np.concatenate([[0],np.cumsum((f[1:]+f[:-1])/2*np.diff(ts))])
    Th=cum(Bo); sL=cum(Bf)[-1]; b18=cum(Bf*np.cosh(Th))[-1]**2
    bnew=sL**2*np.sinh(Th[-1])**2/Th[-1]**2
    # per-mode bound ignoring mixing: eigenvalue paths (sorted) sum sinh^2(int |d ln a_k|/2)
    pm=np.sum(np.sinh(0.5*np.abs(np.diff(np.log(per),axis=0)).sum(0))**2)
    A0=np.real(sqrtm(V(0))); F0=np.linalg.inv(np.real(sqrtm(A0)))/np.sqrt(2)+0j; Fd0=-1j*A0@F0
    def rhs(t,y):
        F=y[:M*M].reshape(M,M); return np.concatenate([y[M*M:],(-V(t)@F).ravel()])
    sol=solve_ivp(rhs,(0,T),np.concatenate([F0.ravel(),Fd0.ravel()]),rtol=1e-9,atol=1e-11,method='DOP853')
    F=sol.y[:M*M,-1].reshape(M,M); Fd=sol.y[M*M:,-1].reshape(M,M)
    A=np.real(sqrtm(V(T))); Ah=np.real(sqrtm(A))
    N=np.linalg.norm((Ah@F-1j*np.linalg.inv(Ah)@Fd)/np.sqrt(2))**2
    return dict(M=M,T=round(T,1),N=N,eq16=np.sinh(sL)**2,eq18=b18,new=bnew,permode=pm,Theta=Th[-1],sqrt2L=sL)
if __name__=='__main__':
    for M in map(int,sys.argv[2:]):
        for v in map(float,sys.argv[1].split(',')):
            t0=time.time(); r=run(M,vmax=v); r['v']=v; r['sec']=round(time.time()-t0)
            print({k:(float('%.4g'%x) if isinstance(x,(float,np.floating)) else x) for k,x in r.items()},flush=True)
def sudden(M,**kw):
    V,Vd,T=setup(M,**kw)
    A0=np.real(sqrtm(V(0))); F0=np.linalg.inv(np.real(sqrtm(A0)))/np.sqrt(2)+0j; Fd0=-1j*A0@F0
    A=np.real(sqrtm(V(T))); Ah=np.real(sqrtm(A))
    return np.linalg.norm((Ah@F0-1j*np.linalg.inv(Ah)@Fd0)/np.sqrt(2))**2
