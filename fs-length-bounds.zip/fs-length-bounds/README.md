# fs-length-bounds

Code and data for the paper

**A. M. Tishin, "Fubini–Study Length Bounds on Particle Creation in Driven Bosonic Systems"** (submitted, 2026).

The scripts reproduce every figure and numerical test of the paper and its Supplementary Material.

Python 3 with numpy, scipy, matplotlib. Run each script from this folder.

| Script | Reproduces |
|---|---|
| fig2.py | Fig. 1 (local criterion vs accumulated excitation), single-mode numbers of Sec. 3.1 |
| ring.py | Moving defect (Sec. 3.2): exact excitation, Eqs. (16), (17), single-mode estimate, sudden displacement |
| ring2.py | Moving defect: Theorem 3 (integrates W, Z, alpha, beta) |
| ringscan.py | Speed scan for Fig. 2 (writes ringscan.json) |
| fig3ring.py | Draws Fig. 2 from ringscan.json |
| kato_mm.py | Corollary 2 (a priori multimode bound) for the moving defect |
| polar.py, polar_chk.py | Theorem 2 in the frame S_t = (2 gamma_t)^(1/2) for random Hamiltonians with x–p couplings (`python3 polar.py 12001`) |
| stress_general.py, stress_general2.py | Random tests of Theorem 1 |
| stress_p3b.py, phase_mm.py | Random tests of Theorem 3 (40 protocols) |
| phase1.py, refined.py | Single-mode and two-mode tests of Theorems 2–3 and Corollary 1 |
| chainbig.py | Chain with fixed normal modes (Supplementary Material S3) |
| frw.py, phase_frw.py | Expanding universe (Sec. 3.4) |

## Requirements

Python 3.10 or later, numpy, scipy, matplotlib:

    pip install numpy scipy matplotlib

## Quick check

    python3 -c "import ring; print(ring.run(20, D=4.0, vmax=4)['N'])"   # 0.0740, Sec. 3.2

Random tests use `numpy.random.default_rng` with the seeds stated in the scripts (7 and 11 for Theorem 1, 3 for Theorem 2, 5 for Theorem 3).

## License

MIT (see LICENSE).
