import numpy as np, sys, json
sys.path.insert(0,'.')
import ring, ring2
vs=np.geomspace(0.25,16,13); out=[]
for v in vs:
    a=ring.run(20,D=4.0,vmax=v); b=ring2.run(20,v=v)
    out.append(dict(v=v,N=a['N'],Nmax=b['Nmax'],eq16=a['eq16'],eq18=a['eq18'],permode=a['permode'],prop3=b['prop3'],PhiF=b['PhiF']))
    print(out[-1],flush=True)
json.dump(out,open('ringscan.json','w'))
print('sudden',ring.sudden(20,D=4.0))
