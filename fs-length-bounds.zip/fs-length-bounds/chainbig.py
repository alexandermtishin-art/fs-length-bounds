import numpy as np
from scipy.integrate import solve_ivp
def chain(M,T=8,steps=4000):
    lam=0.4-0.4*np.cos(np.pi*np.arange(1,M+1)/(M+1))   # eigenvalues of coupling part (open chain, J=0.2)
    ts=np.linspace(0,T,steps)
    c=lambda t:(1+0.5*(1+np.tanh((t-3)/0.3))/2)**2
    cd=lambda t:2*(1+0.5*(1+np.tanh((t-3)/0.3))/2)*0.5*0.5/0.3/np.cosh((t-3)/0.3)**2
    Ntot=0
    W=np.sqrt(c(ts)[:,None]+lam[None,:]); Wd=cd(ts)[:,None]/(2*W)
    rate=np.abs(Wd)/(2*W)              # |omega_dot|/(2 omega) = |B_kk|
    Bf=np.sqrt((rate**2).sum(1)); Bo=rate.max(1)
    cum=lambda f: np.concatenate([[0],np.cumsum((f[1:]+f[:-1])/2*np.diff(ts))])
    Th=cum(Bo); ref=cum(Bf*np.cosh(Th))[-1]**2; sb=np.sinh(cum(Bf)[-1])**2
    # exact per mode via mode equation for a subsample of k, interpolate
    ks=np.unique(np.linspace(0,M-1,min(M,40)).astype(int)); Nk=[]
    for k in ks:
        om=lambda t:np.sqrt(c(t)+lam[k]); w0=om(0)
        f0=1/np.sqrt(2*w0)
        s=solve_ivp(lambda t,y:[y[1],-om(t)**2*y[0]],(0,T),[f0+0j,-1j*w0*f0],rtol=1e-10,atol=1e-12)
        f,fd=s.y[0,-1],s.y[1,-1]; wT=om(T)
        Nk.append(abs(wT*f-1j*fd)**2/(2*wT))   # |beta|^2 = |w f + i fd|^2/(2w)
    N=np.interp(np.arange(M),ks,Nk).sum()
    return N,sb,ref,Th[-1],cum(Bf)[-1]
for M in [5,20,50,200,1000]:
    N,sb,ref,Th,sL=chain(M); print(M, f"N={N:.3f} sinh2={sb:.3e} refined={ref:.3f} Theta={Th:.3f} sqrt2L={sL:.3f}")
