"""Figure 2: domain of validity of the local criterion A0 (exact mode equation f''+Omega^2 f=0 from vacuum)."""
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
def run(O,dO,T,n=20001):
    O0=O(0.0); f0=1/np.sqrt(2*O0)
    rhs=lambda t,y:[y[2],y[3],-O(t)**2*y[0],-O(t)**2*y[1]]
    s=solve_ivp(rhs,(0,T),[f0,0,0,-O0*f0],rtol=1e-11,atol=1e-13,dense_output=True)
    ts=np.linspace(0,T,n); y=s.sol(ts); f=y[0]+1j*y[1]; fd=y[2]+1j*y[3]; o=O(ts)
    dl=np.abs(dO(ts))/o; L=np.concatenate([[0],np.cumsum((dl[1:]+dl[:-1])/2*np.diff(ts))])/np.sqrt(8)
    run.L=L
    return ts,(abs(fd)**2+o**2*abs(f)**2)/(2*o)-0.5,np.abs(dO(ts))/o**2/np.sqrt(8)
eps=0.02; T=100*np.pi
res=run(lambda t:1+eps*np.sin(2*t),lambda t:2*eps*np.cos(2*t),T); Lres=run.L
off=run(lambda t:1+eps*np.sin(1.3*t),lambda t:1.3*eps*np.cos(1.3*t),T)
print(f"resonant: maxA0={res[2].max():.4f} N(T)={res[1][-1]:.2f}  sinh^2(eps T/2)={np.sinh(eps*T/2)**2:.2f}")
print(f"off-res : maxA0={off[2].max():.4f} maxN={off[1].max():.2e}")
tau=0.3
st=run(lambda t:0.75-0.25*np.tanh((t-3)/tau),lambda t:-0.25/tau/np.cosh((t-3)/tau)**2,20)
print(f"ramp+stop: maxA0={st[2].max():.3f} N_end={st[1][-1]:.4f} A0_end={st[2][-1]:.1e}")
# single-pass tanh ramps: Omega from 1 to r, various tau
rows=[]
for r in [0.5,0.25,2.0]:
    for tau in [0.05,0.1,0.2,0.3,0.5,0.8,1.2,2.0]:
        t0=6*tau+2; O=lambda t,r=r,tau=tau,t0=t0:(1+r)/2+(r-1)/2*np.tanh((t-t0)/tau)
        dO=lambda t,r=r,tau=tau,t0=t0:(r-1)/2/tau/np.cosh((t-t0)/tau)**2
        ts,N,A=run(O,dO,2*t0+5,8001); rows.append((r,tau,A.max(),N[-1]))
for row in rows: print("r=%.2f tau=%.2f maxA0=%.3f Nfinal=%.3e"%row)
np.save('fig2_rows.npy',np.array(rows))
C=dict(blue='#0072B2',orange='#D55E00',green='#009E73',purple='#CC79A7',black='#000000',grey='#7F7F7F')
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'font.size':12,'mathtext.fontset':'dejavuserif'})
fig,ax=plt.subplots(1,3,figsize=(12,3.8))
a=ax[0]
a.semilogy(res[0],np.maximum(res[1],1e-8),color=C['orange'],lw=1.6,label=rf'$\omega_m=2\Omega_0$, max $\mathcal{{A}}_0={res[2].max():.3f}$')
a.semilogy(off[0],np.maximum(off[1],1e-8),color=C['blue'],lw=1.2,label=rf'$\omega_m=1.3\Omega_0$, max $\mathcal{{A}}_0={off[2].max():.3f}$')
a.semilogy(res[0],np.sinh(eps*res[0]/2)**2,color=C['black'],ls='--',lw=1,label=r'$\sinh^2(\varepsilon\Omega_0t/2)$')
a.semilogy(res[0],np.sinh(np.sqrt(2)*Lres)**2,color=C['purple'],ls=':',lw=1.6,label=r'bound $\sinh^2(\sqrt{2}L_{\rm FS})$, Eq. (14)')
a.set_ylim(1e-7,1e3); a.set_xlim(0,T); a.set_xlabel(r'$t$'); a.set_ylabel(r'$N_{\rm ex}(t)$')
a.set_title(r'(a)  $\Omega=\Omega_0(1+\varepsilon\sin\omega_m t)$, $\varepsilon=0.02$',loc='left',fontsize=11); a.legend(fontsize=9,loc='upper left',framealpha=0.9)
a=ax[1]; a2=a.twinx()
a.plot(st[0],st[1],color=C['green'],lw=1.8,label=r'$N_{\rm ex}(t)$'); a.set_ylabel(r'$N_{\rm ex}(t)$')
a2.plot(st[0],st[2],color=C['purple'],lw=1.4,ls='--',label=r'$\mathcal{A}_0(t)$'); a2.set_ylabel(r'$\mathcal{A}_0(t)$',color=C['purple']); a2.tick_params(axis='y',colors=C['purple'])
a.set_xlabel(r'$t$'); a.set_xlim(0,20); a.set_title(r'(b)  ramp $\Omega:1\to0.5$ ($\tau=0.3$), then stop',loc='left',fontsize=11)
h1,l1=a.get_legend_handles_labels(); h2,l2=a2.get_legend_handles_labels(); a.legend(h1+h2,l1+l2,fontsize=10,loc='center right')
a=ax[2]; R=np.array(rows)
for r,c,mk in [(0.5,C['blue'],'o'),(0.25,C['orange'],'s'),(2.0,C['green'],'^')]:
    m=R[:,0]==r; Ns=(1-r)**2/(4*r); a.loglog(R[m,2],R[m,3]/Ns,mk,color=c,ms=7,label=rf'$\Omega:1\to{r:g}$')
a.axvline(1,color=C['grey'],ls=':',lw=1); a.text(1.08,1.5e-4,r'$\mathcal{A}_0=1$',color=C['grey'],fontsize=10)
a.set_xlabel(r'$\max_t\,\mathcal{A}_0(t)$'); a.set_ylabel(r'$N_{\rm ex}^{\rm final}/N_{\rm sudden}$'); a.set_title('(c)  single-pass tanh ramps',loc='left',fontsize=11); a.legend(fontsize=9,loc='center right',framealpha=0.9)
for x in ax: x.grid(alpha=0.25,lw=0.5)
fig.tight_layout(); fig.savefig('fig1.jpeg',dpi=400,pil_kwargs={'quality':95}); print('saved')
