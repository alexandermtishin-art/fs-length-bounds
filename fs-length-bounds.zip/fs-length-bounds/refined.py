import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import sqrtm, eigh
def run(Vf, T, n, steps=4000):
    V0=Vf(0.0); w,U=eigh(V0); A0=U@np.diag(np.sqrt(w))@U.T
    F0=np.real(sqrtm(np.linalg.inv(A0)))/np.sqrt(2)+0j     # x = F a0 + c.c. ; F(0)=A^{-1/2}/sqrt2
    Fd0=-1j*A0@F0
    def rhs(t,y):
        F=y[:n*n].reshape(n,n); Fd=y[n*n:].reshape(n,n)
        return np.concatenate([Fd.ravel(), (-Vf(t)@F).ravel()])
    ts=np.linspace(0,T,steps)
    s=solve_ivp(rhs,(0,T),np.concatenate([F0.ravel(),Fd0.ravel()]),t_eval=ts,rtol=1e-10,atol=1e-12)
    Ns=[];Bf=[];Bo=[]
    h=1e-5
    for k,t in enumerate(ts):
        F=s.y[:n*n,k].reshape(n,n); Fd=s.y[n*n:,k].reshape(n,n)
        V=Vf(t); w,U=eigh(V); A=U@np.diag(np.sqrt(w))@U.T; Ai=np.linalg.inv(A)
        # beta: a_t = (A^{1/2} x + i A^{-1/2} p)/sqrt2 ; x=F a0+ conj(F) a0^dag, p=Fd a0 + conj(Fd) a0^dag
        Ah=U@np.diag(w**0.25)@U.T; Ahi=np.linalg.inv(Ah)
        beta=(Ah@np.conj(F)+1j*Ahi@np.conj(Fd))/np.sqrt(2)
        Ns.append(np.real(np.trace(beta@beta.conj().T)))
        Vp=Vf(t+h); wp,Up=eigh(Vp); Ap=Up@np.diag(np.sqrt(wp))@Up.T
        Vm=Vf(t-h) if t>h else Vf(t); wm,Um=eigh(Vm); Am=Um@np.diag(np.sqrt(wm))@Um.T
        Adot=(Ap-Am)/((2*h) if t>h else h)
        B=0.5*Ahi@Adot@Ahi
        Bf.append(np.linalg.norm(B,'fro')); Bo.append(np.linalg.norm(B,2))
    Ns=np.array(Ns);Bf=np.array(Bf);Bo=np.array(Bo)
    cum=lambda f: np.concatenate([[0],np.cumsum((f[1:]+f[:-1])/2*np.diff(ts))])
    L=cum(Bf)/np.sqrt(2); Th=cum(Bo)
    ref=cum(Bf*np.cosh(Th))      # sqrt2 v_FS = ||B||_F
    return Ns, np.sinh(np.sqrt(2)*L)**2, ref**2, Th, L
def R(th): return np.array([[np.cos(th),-np.sin(th)],[np.sin(th),np.cos(th)]])
cases={}
for kap in [0.5,2,10]:
    cases[f'rot k={kap}']=(lambda t,k=kap:R(k*np.tanh(t-3))@np.diag([1,9])@R(k*np.tanh(t-3)).T,8,2)
cases['resonant']=(lambda t:np.array([[1+0.05*np.sin(2*t),0.3],[0.3,2.25]]),60,2)
cases['quench']=(lambda t:np.array([[1,0.45*(1+np.tanh((t-3)/0.05))],[0.45*(1+np.tanh((t-3)/0.05)),2.25]]),8,2)
cases['sumfreq']=(lambda t:np.array([[1,0.08*np.cos(2.5*t)],[0.08*np.cos(2.5*t),2.25]]),80,2)
# chain of M oscillators, uniform quench of on-site frequency 1 -> 1.5 (tanh), nearest neighbour coupling 0.2
for M in [5,20,50]:
    def Vc(t,M=M):
        w2=(1+0.5*(1+np.tanh((t-3)/0.3))/2)**2
        V=np.diag(np.full(M,w2+0.4)); 
        for i in range(M-1): V[i,i+1]=V[i+1,i]=-0.2
        return V
    cases[f'chain M={M}']=(Vc,8,M)
for k,(Vf,T,n) in cases.items():
    N,b,r,Th,L=run(Vf,T,n, steps=3000 if n<20 else 1200)
    print(f"{k:14s} N={N[-1]:.4e} sinh2bound={b[-1]:.4e} refined={r[-1]:.4e} viol_ref={np.max(N-r):.1e} Theta={Th[-1]:.3f} sqrt2L={np.sqrt(2)*L[-1]:.3f}")
