# Supplementary Material

**Particle Creation Bounds for Inhomogeneous Klein–Gordon Fields**  
A. M. Tishin · Computational details for manuscript v31 · 10 November 2026

Numbered equations in this supplement are labeled (S1)–(S8). Other equation, theorem, section, and figure numbers refer to manuscript v31. The [repository README](README.md) gives the Python environment and reproduction commands.

## S1. Bogoliubov–Valatin equations

For the oscillator $\hat H(t)=p^2/2+\Omega^2(t)x^2/2$, the instantaneous Bogoliubov coefficients satisfy Eq. (11) with $u(0)=1$ and $v(0)=0$. We independently integrate the classical mode equation

$$
\ddot f+\Omega^2(t)f=0,\qquad
f(0)=\frac1{\sqrt{2\Omega_0}},\qquad
\dot f(0)=-i\Omega_0 f(0).\tag{S1}
$$

The instantaneous occupation is

$$
N_{\mathrm{ex}}(t)=\frac{|\dot f|^2+\Omega^2(t)|f|^2}{2\Omega(t)}-\frac12.\tag{S2}
$$

The integrations agree to $10^{-8}$, the accuracy set by output interpolation. The Wronskian $\operatorname{Im}(f^*\dot f)$ and the invariant $|u|^2-|v|^2$ are conserved to $6\times10^{-11}$ and $2\times10^{-11}$, respectively. The solver is SciPy's RK45 with relative tolerance $10^{-11}$ and absolute tolerance $10^{-13}$.

## S2. Single-mode tests for Figure 2

The [Figure 2 calculation](code/fig2.py) starts from the instantaneous vacuum and uses the mode equation and solver settings in S1.

- **Panel (a).** $\Omega(t)=1+0.02\sin(\omega_m t)$ on $0\le t\le100\pi$. At $\omega_m=2$, $N_{\mathrm{ex}}(100\pi)=133.25$, compared with the Mathieu estimate $\sinh^2(0.01\cdot100\pi)=133.37$.
- **Panel (b).** A tanh ramp from $1$ to $0.5$ has centre $t_0=3$ and width $\tau=0.3$. The frequency is then held constant and the evolution is integrated to $t=20$.
- **Panel (c).** Tanh ramps from $1$ to $r\in\{0.5,0.25,2\}$ use $\tau\in\{0.05,0.1,0.2,0.3,0.5,0.8,1.2,2\}$. Corollary 1 also uses $\tau=5$. The centre is $t_0=6\tau+2$ and the final time is $2t_0+5$. The sudden-quench reference is $(1-r)^2/(4r)$.

## S3. Multimode and field tests

### Mode matrix and coupled protocols

Write $A=V^{1/2}$ and $\hat x(t)=F(t)\hat a_0+\bar F(t)\hat a_0^\dagger$. The initial conditions are $F(0)=A(0)^{-1/2}/\sqrt2$ and $\dot F(0)=-iA(0)F(0)$. The multimode tests use RK45 with relative tolerance $10^{-10}$ and absolute tolerance $10^{-12}$. The instantaneous Bogoliubov matrix and total occupation are

$$
\beta=\frac{A^{1/2}\bar F+iA^{-1/2}\dot{\bar F}}{\sqrt2},
\qquad N_{\mathrm{tot}}=\|\beta\|_F^2.\tag{S3}
$$

The squeezing parameters are $r_k=\operatorname{arsinh}\sigma_k(\beta)$ and determine $d_G$ through Theorem 1. We compute $B$ from central differences of $A$ with step $10^{-5}$ and use the trapezoidal rule for $Z$, $L_{\mathrm{FS}}$, and $\Theta$ on about 3000 time points.

For the [chain](code/chainbig.py), $V=c(t)I+K$, where $K$ is tridiagonal with diagonal $0.4$ and off-diagonal $-0.2$. We use $c(t)=[1+0.25(1+\tanh((t-3)/0.3))]^2$ and integrate the fixed normal modes separately to $t=8$.

| Modes | Excitation | Sum of Eq. (14) over modes | Squared right side of Eq. (17) | Eq. (16) |
| ---: | ---: | ---: | ---: | ---: |
| 50 | 0.82 | 1.377 | 1.384 | 2.1 |
| 200 | 3.29 | 5.51 | 5.54 | 26 |
| 1000 | 16.5 | 27.6 | 27.7 | $8.7\times10^3$ |

The two-mode rotations in Appendix C.2 use

$$
V(t)=R(\phi)\operatorname{diag}(1,9)R(\phi)^{\mathsf T},
\quad
R(\phi)=\begin{pmatrix}\cos\phi&-\sin\phi\\\sin\phi&\cos\phi\end{pmatrix},
\quad
\phi(t)=\kappa\tanh(t-3)\tag{S4}
$$

with $\kappa=0.5,2,10$ and final time $8$. Other protocols use diagonal entries $V_{11}=1$ and $V_{22}=2.25$ except when $V_{11}$ is modulated. They use $V_{11}(t)=1+0.05\sin(2t)$ with $J=0.3$ to $t=60$, the coupling ramp $J(t)=0.45[1+\tanh((t-3)/0.05)]$ to $t=8$, or $J(t)=0.08\cos(2.5t)$ to $t=80$. The off-resonant phase-sensitive test uses $J(t)=0.08\cos(0.9t)$ to $t=80$.

For Theorem 3, $W$, $\alpha$, $\beta$, and $Z$ are integrated together with DOP853. For two modes the relative and absolute tolerances are $10^{-9}$ and $10^{-11}$. For one mode the relative tolerance is $10^{-11}$. The running maximum of $\|Z\|$ uses about 3000 time points for two modes and $2\times10^5$ for one mode. See the [two-mode script](code/phase_mm.py).

### Homogeneous expanding background

To check Eq. (27), we integrate from conformal time $-(40/\rho+20)$ to $40/\rho+20$. Agreement is better than $10^{-8}$ relative for $\rho=2,10$. For $\rho=0.5$ and $k\ge1$, the particle number falls below $10^{-7}$ and the comparison is limited by double precision.

For Section 4.4, [phase_frw.py](code/phase_frw.py) integrates the Bogoliubov equations and phase integral in $s=\rho t$ using DOP853 with relative tolerance $10^{-10}$ and absolute tolerance $10^{-13}$. It separates the constant-frequency carrier from the phase correction. It samples $\Phi$ on 20,001 equally spaced points in $-18\le s\le18$. The integrated coupling of the omitted tails is at most $(1-\tanh18)/[2(k^2+1)]<2.4\times10^{-16}$.

The script reports peak and final occupations at $k=0,1,3$. It uses trapezoidal quadrature on 21 linear momenta in $0\le k\le5$ and 40 logarithmic momenta in $5.3\le k\le300$. The estimated density ceilings for $\rho=0.5,2,10$ are $1.71508\times10^{-5}$, $6.38252\times10^{-4}$, and $4.59910\times10^{-3}$. Refinement changes these estimates by at most $0.061\%$. Run `python phase_frw.py --refined` from `code/` for 41 linear and 80 logarithmic momenta, 40,001 time samples, relative tolerance $10^{-11}$, and absolute tolerance $10^{-14}$. See the [standard](validation/flrw_standard.txt) and [refined](validation/flrw_refined.txt) outputs.

For $k\ge K=300$, Corollary 1 gives $\Phi(k)\le\rho/(4k^3)$ and $\Theta(k)=\tfrac14\log[(k^2+3)/(k^2+1)]\le1/(2k^2)$. Equation (20) bounds the density tail by $\rho^2 C(K)/(96\pi^2 K^3)$, where

$$
C(K)=\left(1-\frac{\rho}{4K^3}\right)^{-2}
\exp\left[\frac{\rho/(4K^3)}{K^2(1-\rho/(4K^3))}\right].\tag{S5}
$$

The tail is below $4\times10^{-9}$ at all three rates. The sampled maxima and quadrature on $0\le k\le K$ give numerical estimates of the analytic ceiling.

### Moving defect and random checks

The [ring calculation](code/ring.py) integrates the mode matrix with DOP853 at relative tolerance $10^{-9}$ and absolute tolerance $10^{-11}$. It evaluates $B$ from $\dot V$ in the instantaneous eigenbasis on 100 points per unit time. The [phase-sensitive ring calculation](code/ring2.py) integrates $W$, $Z$, $\alpha$, and $\beta$ with fourth-order Runge–Kutta at step $0.004$. The final occupations agree to four digits. The defect starts at $x_a=M/4$ and remains at rest for two time units after moving. The single-mode comparison is $\sum_k\sinh^2(\tfrac12\int|\dot\omega_k/\omega_k|\,dt)$ with the instantaneous frequencies ordered by size. See the [Figure 3 data](code/ringscan.json).

- **Theorem 1.** The 94 accepted protocols cover one to three modes. They use $h=h_0+a(t)P$, $h_0=QQ^{\mathsf T}+cI$ with Gaussian $Q$ and $c=1.5$ or $2$, and random symmetric $P$ with $x$–$p$ blocks. The periodic frequencies span $0.3$–$3$ and the tanh widths $0.005$–$1$, with $h$ kept positive definite. Both inequalities in Eq. (15) hold to integration accuracy. The excitation-to-length-bound ratio reaches $0.9996$ for the fastest quenches.
- **Theorem 2.** Twelve periodic or tanh protocols cover two and three modes with $x$–$p$ blocks. The frame is $S_t=(2\gamma_t)^{1/2}$ with $2\gamma_t=h^{-1/2}|h^{1/2}Jh^{1/2}|h^{-1/2}$. The pair term comes from the part of $-S_t^{-1}\dot S_t$ that anticommutes with $J$. The Heisenberg propagator uses relative tolerance $10^{-10}$. The identity $\|B\|_F=\sqrt2\,v_{\mathrm{FS}}$ holds to $10^{-11}$. The relative excess over Eqs. (16)–(17) is at most $2\times10^{-4}$, consistent with the excess over Eq. (15) from time discretization near $t=0$.
- **Theorem 3.** Forty two- and three-mode protocols use $V=V_0+a(t)P$ with $V_0=QQ^{\mathsf T}+I$ and $\|P\|_{\mathrm{op}}=1$. The amplitude is $0.05$–$0.6$ times the smallest eigenvalue of $V_0$. Periodic frequencies are $0.2$–$4$ and tanh widths $0.03$–$3$. The final time is $12$.

The random protocols use NumPy's `default_rng` with seeds 7 and 11 for Theorem 1, 3 for Theorem 2, and 5 for Theorem 3. See the [code index](code/README.md). For Corollary 2 we compute $X$ in the eigenbasis of $A$ and use central differences at step $10^{-5}$ for its time derivative.

## S4. Coupled scalar field on a three-torus

The [torus calculation](torus/coupled_torus.py) uses a real scalar field on a torus of side $2\pi$, reference mass $1$, final time $1$, and spherical Fourier cutoff $\Lambda$. The addition to the squared mass is

$$
U(t,x)=g(t)\left(1+\frac{\cos x_1}{2}\right),\qquad
g(t)=\frac{1-\cos(\pi t)}2 .\tag{S6}
$$

At fixed transverse labels $k_2,k_3$, $V=\operatorname{diag}(1+|k|^2)+g(t)P$. The matrix $P$ has diagonal entries $1$ and entries $1/4$ between adjacent retained longitudinal labels. Blocks are grouped by $k_2^2+k_3^2$ and all signed transverse labels count towards the real field's mode space without an extra factor of two.

In each block $Q'=P_m$ and $P_m'=-VQ$, with $Q(0)=F_0^{-1}$, $P_m(0)=-iF_0$, and $F_t=V(t)^{1/4}$. The block particle number in the final instantaneous vacuum convention is

$$
\left\|\frac{F_1 Q(1)-i F_1^{-1} P_m(1)}2\right\|_F^2 .\tag{S7}
$$

Summing with the transverse multiplicities gives $N_\Lambda$. DOP853 uses relative and absolute tolerances $10^{-10}$ and $10^{-11}$. The tighter check at $\Lambda=18$ uses $10^{-12}$ and $10^{-13}$.

Put $a_k=(1+|k|^2)^{-1}$. The integrated drive norm is $3/2$, so Eq. (28) at finite cutoff gives the supremum-based bound $\sinh^2(3/8)\sum_{|k|\le\Lambda}a_k^2$. The pair-block estimate in Eq. (30) and the operator bound in Eq. (31) give the profile-dependent bound $W_\Lambda\sinh^2(3/8)/(3/2)^2$, where

$$
W_\Lambda=\sum_{|k|\le\Lambda}a_k^2+
\frac18\sum_{|k|,\,|k+e_1|\le\Lambda}a_k a_{k+e_1}.\tag{S8}
$$

Here $e_1=(1,0,0)$. This is the squared Hilbert–Schmidt norm of $V_0^{-1/2}PV_0^{-1/2}$ on the retained space. Both sums use the same modes as the dynamics. Cauchy–Schwarz bounds the shifted overlap by the unshifted trace. The squared spatial RMS amplitude is $9/8$, so the intermediate RMS bound is half the supremum-based bound. At $\Lambda=18$ the bounds are $1.370508434536$, $0.685254217268$, and $0.678661547642$, respectively. The reduction from the RMS bound to the profile-dependent bound is $0.9621\%$.

From the repository root, run:

~~~sh
cd torus
OPENBLAS_NUM_THREADS=1 python coupled_torus.py > coupled_torus_rerun.csv
OPENBLAS_NUM_THREADS=1 python coupled_torus.py --cutoff 18 --rtol 1e-12 --atol 1e-13 > coupled_torus_tight_rerun.csv
python plot_field_bounds.py
~~~

The [standard](torus/coupled_torus.csv) and [tighter](torus/coupled_torus_tight.csv) CSVs record finite-cutoff particle numbers and upper bounds. The tolerance comparison checks numerical stability. Theorems 4–5 establish convergence as the cutoff is removed.
