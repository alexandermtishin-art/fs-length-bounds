#!/usr/bin/env python3
"""Finite-cutoff test of the particle-number bound for a coupled scalar field.

The torus side is 2*pi, the reference mass is 1 and 0 <= t <= 1.
The drive is U(t,x) = (1 - cos(pi*t))/2 * (1 + cos(x_1)/2).
The spherical Fourier cutoff keeps integer k with |k| <= cutoff.
Run: OPENBLAS_NUM_THREADS=1 python coupled_torus.py > coupled_torus.csv
Requires NumPy and SciPy.
"""
import argparse
from collections import Counter
import csv
from math import isqrt
import sys

import numpy as np
from scipy.integrate import solve_ivp


def transverse_shells(cutoff):
    """Group signed transverse pairs by their squared radius."""
    limit = cutoff * cutoff
    counts = Counter()
    for k2 in range(-cutoff, cutoff + 1):
        k3_limit = isqrt(limit - k2 * k2)
        for k3 in range(-k3_limit, k3_limit + 1):
            counts[k2 * k2 + k3 * k3] += 1
    return counts


def block_occupation(reference, rtol, atol):
    """Evolve complex positive-frequency initial data in one longitudinal block."""
    n = len(reference)
    potential = np.eye(n)
    neighbors = np.arange(n - 1)
    potential[neighbors, neighbors + 1] = 0.25
    potential[neighbors + 1, neighbors] = 0.25
    # The mode matrices omit the common 1/sqrt(2) in the canonical expansion.
    f_initial = np.power(reference, 0.25)
    positions = np.diag(1.0 / f_initial)
    momenta = -1j * np.diag(f_initial)
    initial = np.stack((positions, momenta)).ravel()

    def derivative(t, state):
        positions, momenta = state.reshape(2, n, n)
        scale = 0.5 * (1.0 - np.cos(np.pi * t))
        force = reference[:, None] * positions + scale * (potential @ positions)
        return np.stack((momenta, -force)).ravel()

    solution = solve_ivp(
        derivative, (0.0, 1.0), initial, method="DOP853",
        rtol=rtol, atol=atol, t_eval=[1.0],
    )
    if not solution.success:
        raise RuntimeError(solution.message)
    positions, momenta = solution.y[:, -1].reshape(2, n, n)
    final_eigenvalues, final_modes = np.linalg.eigh(np.diag(reference) + potential)
    f_final = final_eigenvalues ** 0.25
    q_final = f_final[:, None] * (final_modes.T @ positions)
    p_final = (final_modes.T @ momenta) / f_final[:, None]
    # Up to conjugation and reversal of Fourier labels, the final pair block.
    beta = 0.5 * (q_final - 1j * p_final)
    return float(np.vdot(beta, beta).real)


def calculate(cutoff, rtol, atol):
    particle_number = 0.0
    reference_trace = 0.0
    weighted_trace = 0.0
    mode_count = 0
    for radius_squared, multiplicity in sorted(transverse_shells(cutoff).items()):
        longitudinal_limit = isqrt(cutoff * cutoff - radius_squared)
        k1 = np.arange(-longitudinal_limit, longitudinal_limit + 1)
        reference = k1 * k1 + radius_squared + 1.0
        particle_number += multiplicity * block_occupation(reference, rtol, atol)
        inverse = 1.0 / reference
        diagonal_trace = float(inverse @ inverse)
        neighbor_trace = float(inverse[:-1] @ inverse[1:])
        reference_trace += multiplicity * diagonal_trace
        # The two off-diagonals of the drive each have coefficient 1/4.
        weighted_trace += multiplicity * (diagonal_trace + neighbor_trace / 8.0)
        mode_count += multiplicity * len(k1)
    # J_T = 3/2. The reference mass in Eq. (28) is 1.
    integrated_growth = np.sinh(3.0 / 8.0) ** 2
    regulated_bound = reference_trace * integrated_growth
    rms_bound = 0.5 * regulated_bound
    weighted_bound = weighted_trace * integrated_growth / (1.5 ** 2)
    return mode_count, particle_number, regulated_bound, rms_bound, weighted_bound


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cutoff", type=int, nargs="+", default=[2, 4, 8, 12, 18])
    parser.add_argument("--rtol", type=float, default=1e-10)
    parser.add_argument("--atol", type=float, default=1e-11)
    args = parser.parse_args()
    if min(args.cutoff) < 0:
        parser.error("cutoffs must be nonnegative")
    writer = csv.writer(sys.stdout, lineterminator="\n")
    writer.writerow((
        "cutoff", "mode_count", "particle_number", "regulated_bound",
        "rms_bound", "weighted_bound", "rtol", "atol",
    ))
    for cutoff in args.cutoff:
        count, particles, bound, rms, weighted = calculate(cutoff, args.rtol, args.atol)
        writer.writerow((
            cutoff, count, f"{particles:.12f}", f"{bound:.12f}", f"{rms:.12f}", f"{weighted:.12f}",
            args.rtol, args.atol,
        ))


if __name__ == "__main__":
    main()
