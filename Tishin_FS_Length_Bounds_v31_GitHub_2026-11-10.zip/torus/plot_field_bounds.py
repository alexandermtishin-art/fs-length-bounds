"""Build the field comparison from the archived finite-cutoff run."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

directory = Path(__file__).resolve().parent
data = np.genfromtxt(directory / "coupled_torus.csv", delimiter=",", names=True)
cutoff = data["cutoff"]
fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.45), layout="constrained",
                         gridspec_kw={"width_ratios": [1.55, 1]})
ax = axes[0]
ax.plot(cutoff, data["regulated_bound"], "s-", color="#51616f", label="Supremum bound")
ax.plot(cutoff, data["rms_bound"], "o--", color="#ad4d26", label="RMS bound")
ax.plot(cutoff, data["weighted_bound"], "x:", color="#11656c", label="Spectrum-resolved bound")
ax.plot(cutoff, data["particle_number"], "D-", color="#272727", label="Computed count")
ax.set(xlabel=r"Fourier cutoff $\Lambda$", ylabel=r"Particle count or upper bound")
legend = ax.legend(
    loc="lower left", bbox_to_anchor=(0.0, 1.035), ncols=2,
    frameon=False, fontsize=8.5, borderaxespad=0.0, columnspacing=1.2,
    handlelength=1.8, handletextpad=0.5,
)
ax = axes[1]
reduction = 100 * (1 - data["weighted_bound"] / data["rms_bound"])
ax.plot(cutoff, reduction, "o-", color="#11656c")
ax.set(xlabel=r"Fourier cutoff $\Lambda$", ylabel="Reduction from RMS bound (%)")
for ax in axes:
    ax.set_xticks(cutoff)
    ax.grid(alpha=0.23)
    ax.spines[["top", "right"]].set_visible(False)
# The legend occupies its own row, above the data panels.
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
legend_box = legend.get_window_extent(renderer)
assert legend_box.y0 > max(ax.get_window_extent(renderer).y1 for ax in axes)
left_box = axes[0].get_window_extent(renderer)
assert left_box.x0 - 0.1 <= legend_box.x0 < legend_box.x1 <= left_box.x1
assert len({round(t.get_window_extent(renderer).y0, 1) for t in legend.get_texts()}) == 2
assert legend_box.y1 <= fig.bbox.y1
fig.savefig(directory / "field_bounds.png", dpi=300, facecolor="white")
