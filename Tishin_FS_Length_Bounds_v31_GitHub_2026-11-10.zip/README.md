# Particle Creation Bounds for Inhomogeneous Klein–Gordon Fields

This repository contains code, data, and figures for the calculations accompanying A. M. Tishin's manuscript *Particle Creation Bounds for Inhomogeneous Klein–Gordon Fields*, revision v31 (10 November 2026).

## Environment

The reference environment is Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, and Matplotlib 3.10.8. From the repository root, install the pinned Python packages:

```sh
python -m pip install -r code/requirements.txt
export OPENBLAS_NUM_THREADS=1
export MPLBACKEND=Agg
```

## Figure 1 and torus data

Run from `torus/`:

```sh
python coupled_torus.py > coupled_torus_rerun.csv
python coupled_torus.py --cutoff 18 --rtol 1e-12 --atol 1e-13 > coupled_torus_tight_rerun.csv
python plot_field_bounds.py
```

The distributed CSVs are the reference outputs for the two commands. The plot reads `coupled_torus.csv` and produces `field_bounds.png`. The columns compare the computed finite-cutoff occupation with the supremum, RMS, and spectrum-resolved bounds.

## FLRW and finite-mode calculations

Run from `code/`:

```sh
python phase_frw.py
python phase_frw.py --refined
python fig2.py
python fig3ring.py
```

The two FLRW runs print sampled estimates on different momentum grids and report the analytic tail bound separately. `fig2.py` creates `fig2.jpeg` and `fig2_rows.npy`. `fig3ring.py` draws `fig3ring.jpeg` from the distributed `ringscan.json`. Run `python ringscan.py` in the same directory to regenerate the ring data. [Additional scripts](code/README.md) reproduce the supporting examples.

## Verification

The [validation directory](validation/README.md) records the reproducibility checks and their outputs. From the repository root, `sha256sum -c SHA256SUMS` checks the integrity of the distributed files. The scripts reproduce numerical examples. The continuum results are analytical.

## Citation and license

See [CITATION.cff](CITATION.cff) for attribution and [LICENSE](LICENSE) for the code license.

The [supplementary material](Supplement_v31.md) describes the numerical protocols and uses the equation numbers of manuscript v31.
