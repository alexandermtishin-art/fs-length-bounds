# Reproducibility checks for v31

The checks were run on 10 November 2026 with Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, and Matplotlib 3.10.8. Numerical commands used `OPENBLAS_NUM_THREADS=1`. Plotting used the noninteractive Agg backend.

- Both torus calculations reproduced the distributed [standard CSV](../torus/coupled_torus.csv) and [tight-tolerance CSV](../torus/coupled_torus_tight.csv) byte for byte.
- All three plotting scripts reproduced the distributed images byte for byte. Figure 2 also reproduced the distributed [source array](../code/fig2_rows.npy). See its [run output](figure2.txt).
- [Standard](flrw_standard.txt) and [refined](flrw_refined.txt) FLRW run outputs give the sampled density estimates and the separately evaluated analytic tail bounds.
- The ring simulation reproduced the distributed [ring scan data](../code/ringscan.json) across all 13 speeds with relative tolerance 10⁻⁸ and absolute tolerance 10⁻¹². See the [run output](ringscan_log.txt). Figure 3 was rendered from the distributed data.

These are checks of the finite numerical examples. The analytical continuum results have separate proofs.

The Figure 1 layout places the legend above the plotting panels. The plotting script checks that the legend and the data panels are disjoint. The two reference CSVs are identical to v29.

Figure 1 has a two-row legend confined to the left panel. Figure 2 places each panel title and legend in a separate band above its own axes. The plot scripts check their annotation bounds. The Figure 2 run reproduces the stored array and log byte for byte.
