"""Sample the phase-sensitive estimate for the homogeneous FLRW example."""
import argparse
from math import cosh, exp, log, log1p, pi, sqrt, tanh

import numpy as np
from scipy.integrate import solve_ivp, trapezoid

A, B, MASS = 2.0, 1.0, 1.0
ACTIVE_LIMIT = 18.0


def endpoint_frequencies(k):
    return sqrt(k * k + MASS**2 * (A - B)), sqrt(k * k + MASS**2 * (A + B))


def exact(k, rho):
    omega_in, omega_out = endpoint_frequencies(k)
    half_difference = MASS**2 * B / (omega_in + omega_out)
    scale = pi / rho

    def log_sinh(x):
        return x - log(2.0) + np.log(-np.expm1(-2.0 * x))

    return exp(2 * log_sinh(scale * half_difference)
               - log_sinh(scale * omega_in) - log_sinh(scale * omega_out))


def sudden(k):
    omega_in, omega_out = endpoint_frequencies(k)
    difference = 2 * MASS**2 * B / (omega_in + omega_out)
    return difference**2 / (4 * omega_in * omega_out)


def phase(k, rho, *, samples=20001, rtol=1e-10, atol=1e-13):
    omega_in, _ = endpoint_frequencies(k)
    active = ACTIVE_LIMIT
    scale = MASS**2 * B

    def rhs(s, state):
        u, v, _, phase_correction = state
        delta = scale * (1.0 + tanh(s))
        omega_squared = omega_in**2 + delta
        omega = sqrt(omega_squared)
        coupling = scale / (4.0 * omega_squared * cosh(s)**2)
        # Separate the carrier so the solver tracks only its small phase correction.
        angle = (s + active) * omega_in / rho + phase_correction.real
        rotation = np.exp(-2j * angle)
        return (coupling * rotation.conjugate() * v,
                coupling * rotation * u, coupling * rotation,
                delta / (rho * (omega + omega_in)))

    grid = np.linspace(-active, active, samples)
    # The integrated coupling omitted from both tails is below 2.4e-16
    # for all sampled k. The starting carrier phase cancels in both moduli.
    result = solve_ivp(rhs, (-active, active), [1 + 0j, 0j, 0j, 0j],
                       rtol=rtol, atol=atol, method="DOP853", t_eval=grid)
    if not result.success:
        raise RuntimeError(f"FLRW integration failed for k={k}, rho={rho}: {result.message}")
    occupation = np.abs(result.y[1])**2
    phi = np.abs(result.y[2]).max()
    theta = 0.25 * log1p(2.0 * scale / omega_in**2)
    if phi < 1.0:
        ceiling = (phi / (1.0 - phi))**2 * exp(2.0 * phi * theta / (1.0 - phi))
    else:
        ceiling = np.inf
    return occupation.max(), occupation[-1], ceiling


def density_tail_bound(cutoff, rho):
    # Corollary 1 gives Phi_k <= rho*m^2*B/(4 k^3); Theta_k <= m^2*B/(2 k^2).
    coefficient = rho * MASS**2 * B / 4.0
    phi = coefficient / cutoff**3
    theta = MASS**2 * B / (2.0 * cutoff**2)
    correction = exp(2.0 * phi * theta / (1.0 - phi)) / (1.0 - phi)**2
    return correction * coefficient**2 / (6.0 * pi**2 * cutoff**3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refined", action="store_true",
                        help="Use the refined grid and tolerances from Supplement S3")
    refined = parser.parse_args().refined
    linear, logarithmic = (41, 80) if refined else (21, 40)
    momenta = np.concatenate((np.linspace(0.0, 5.0, linear),
                              np.geomspace(5.3, 300.0, logarithmic)))
    settings = dict(samples=40001, rtol=1e-11, atol=1e-14) if refined else {}
    for rho in (0.5, 2.0, 10.0):
        results = {k: phase(k, rho, **settings) for k in momenta}
        for k in (0.0, 1.0, 3.0):
            maximum, final, phase_ceiling = results[k]
            print(f"rho={rho:g} k={k:g} exact={exact(k, rho):.8e} "
                  f"Nend={final:.8e} maxN={maximum:.8e} "
                  f"phase_estimate={phase_ceiling:.8e} sudden={sudden(k):.8e}")
        best = [min(results[k][2], sudden(k)) for k in momenta]
        estimate = trapezoid(momenta**2 * best, x=momenta) / (2.0 * pi**2)
        tail = density_tail_bound(momenta[-1], rho)
        print(f"rho={rho:g} sampled_density_k_le_300={estimate:.8e} "
              f"analytic_tail_upper_bound={tail:.8e}", flush=True)


if __name__ == "__main__":
    main()
